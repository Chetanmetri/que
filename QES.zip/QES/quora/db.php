<?php

$conn = "";

try {
	$servername = "localhost:3307";
	$dbname = "quora";
	$username = "root";
	$password = "";

	$conn = new PDO(
		"mysql:host=$servername; dbname=quora",
		$username, $password
	);
	
$conn->setAttribute(PDO::ATTR_ERRMODE,
					PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e) {
	echo "Connection failed: " . $e->getMessage();
}

?>
